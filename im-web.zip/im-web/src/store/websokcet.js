import {defineStore} from "pinia";


export const websocketStore = defineStore("",{
    state:()=>{
        return{
            msg:'',
        }
    },
    getters:{

    },
    actions:{


    }
})
